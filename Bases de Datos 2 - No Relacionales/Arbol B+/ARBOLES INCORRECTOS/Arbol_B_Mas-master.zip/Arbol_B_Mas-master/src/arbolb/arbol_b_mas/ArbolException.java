/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbolb.arbol_mas;
/**
 *
 * @author krysthyan
 */
public class ArbolException extends Exception {
    protected ArbolException(String message) {
        super(message);
    }
}
